

package com.secrethq.utils;

public class PTJniHelper {
	public static native void loadModelController();
	public static native boolean isAdNetworkActive( String name ); 
}
