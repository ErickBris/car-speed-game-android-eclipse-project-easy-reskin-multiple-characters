package com.secrethq.ads;
import org.cocos2dx.lib.Cocos2dxActivity;

public class PTAdHeyzapBridge {
	public static void initBridge(Cocos2dxActivity activity){
	}

	public static void initBanner(){
	}

	public static void initInterstitial(){
	}

	public static void initVideo() {
	}

	public static void startSession( String sdkKey ){
	}

	public static void showFullScreen(){
	}

	public static void showBannerAd(){
	}

	public static void showRewardedVideo(){
	}

	public static void hideBannerAd(){
	}

	public static boolean isBannerVisisble() {
		return false;
	}

	public static boolean isRewardedVideoAvialable(){
		return false;
	}

}
